package net.datasa.itsme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
