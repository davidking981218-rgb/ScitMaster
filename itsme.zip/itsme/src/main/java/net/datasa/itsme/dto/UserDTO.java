package net.datasa.itsme.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String userId;
    private String password;
    private String userName;
    private String phoneNumber;
}
