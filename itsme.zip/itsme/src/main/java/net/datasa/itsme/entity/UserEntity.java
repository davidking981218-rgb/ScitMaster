package net.datasa.itsme.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
// 엔티티는 밑에 두개 꼭 붙여야함
@Entity // DB의 테이블과 매핑되는 클라스
@Table(name = "User")
public class UserEntity {
    @Id // primarykey
    @Column(name="userId", nullable=false, length=30) //테이블의 컬럼과 매핑됨
    String userId;

    @Column (name = "password")// 즉, 컬럼에대한 정보를 넘기는거
    String password;
    @Column (name = "userName")
    String userName;
    @Column (name = "phoneNumber")
    String phoneNumber;
}
