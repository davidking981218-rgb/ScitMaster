package net.datasa.itsme.repository;

import net.datasa.itsme.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository
        extends JpaRepository <UserEntity, String>{
    //person1 테이블에 대한 작업, 그 테이블의 primary key 는 문자열이다

}
