package net.datasa.itsme;


import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import net.datasa.itsme.dto.UserDTO;
import net.datasa.itsme.entity.UserEntity;
import net.datasa.itsme.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@Controller //콘트롤러는 객체를 만들어버림
public class HomeController {
    @Autowired
    UserService service;

    @GetMapping({"", "/"})
    public String home() {
        return "home"; //own1.html로 포워딩
    }

    @GetMapping("join_membership")
    public String join_membership() {
        return "join_membership";
    }

    @GetMapping("login")
    public String login(@CookieValue(name = "savedId", required = false) String savedId,
                        Model model) {
        if (savedId != null) {
            model.addAttribute("savedId", savedId);
        }
        return "login";
    }

    @PostMapping("input")
    public String input(@ModelAttribute UserDTO dto) {
        log.debug("전달받은값 : {}", dto);
        service.insertUser(dto);

        return "redirect:/";
    }

    @GetMapping("/test")
    public String test(HttpSession session) {
        String id = (String) session.getAttribute("userId");
        if (id != null) {
            return "home";
        } else {
            return "redirect:/login";
        }

    }
    @GetMapping("membership_list")
    public String selectAll(Model model) {
        List<UserDTO> list = service.membership_list();
        model.addAttribute("list", list);
        return "membership_list";
    }

    @PostMapping("login")
    public String loginProcess(UserDTO dto, HttpSession session, @RequestParam(value = "rememberId", required = false) boolean rememberId, HttpServletResponse response) {
        UserEntity result = service.login(dto);

        if (result == null) {
            return "redirect:/login"; // 다시 로그인 창으로 쫓아냄
        }
        Cookie cookie = new Cookie("savedId", result.getUserId());
        cookie.setPath("/"); // 모든 경로에서 쿠키 사용 가능하도록 설정

        if (rememberId) {
            cookie.setMaxAge(60 * 60 * 24 * 7);
        } else {
            cookie.setMaxAge(0);
        }

        response.addCookie(cookie);

        session.setAttribute("userId", result.getUserId());
        session.setAttribute("password", result.getPassword());

        return "redirect:/";
    }

    @GetMapping ("logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "home";
    }
}

