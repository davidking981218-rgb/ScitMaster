package net.datasa.itsme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItsmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItsmeApplication.class, args);
	}

}
