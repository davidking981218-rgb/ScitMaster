package net.datasa.itsme.service;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.datasa.itsme.dto.UserDTO;
import net.datasa.itsme.entity.UserEntity;
import net.datasa.itsme.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 회원 관련 처리 서비스
 */
@Slf4j//이 어노테이션들을설명 할 수 있어야함
@Transactional
@Service
public class UserService {

    // 의존성 주입.
    @Autowired
    UserRepository repository;

    public void insertUser(UserDTO dto) {
        UserEntity entity = new UserEntity();
        entity.setUserId(dto.getUserId());
        entity.setPassword(dto.getPassword());
        entity.setUserName(dto.getUserName());
        entity.setPhoneNumber(dto.getPhoneNumber());
        repository.save(entity);
    }

    public void deleteUser(String userId) {
        //테이블의 primary key 기준으로 삭제
        repository.deleteById(userId);
    }

    public UserDTO selectUser(String userId) {
        //테이블의 primary key 기준으로 삭제
        UserEntity entity = repository.findById(userId).orElse(null);
        UserDTO dto = null;
        if (entity != null) {
            dto = new UserDTO();
            dto.setUserId(entity.getUserId());
            dto.setPassword(entity.getPassword());
            dto.setUserName(entity.getUserName());
            dto.setPhoneNumber(entity.getPhoneNumber());
        }
        return dto;
    }

    public List<UserDTO> membership_list() {
        List<UserEntity> entityList = repository.findAll();
        List<UserDTO> dtoList = new ArrayList<>();

        for (UserEntity entity : entityList) {
            UserDTO dto = new UserDTO();
            dto.setUserId(entity.getUserId());
            dto.setPassword(entity.getPassword());
            dto.setUserName(entity.getUserName());
            dto.setPhoneNumber(entity.getPhoneNumber());
            dtoList.add(dto);
        }
        return dtoList;
    }

    public UserEntity login(UserDTO dto) {UserEntity user = repository.findById(dto.getUserId()).orElse(null);
        if (user == null) {
            return null;
        }
        if (!user.getPassword().equals(dto.getPassword())) {
            return null;
        }
        return user;
    }
}
