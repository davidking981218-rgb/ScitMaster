function joinCheck() {
        // 1. 값 가져오기 (id로 찾습니다)
        const userId = document.getElementById('userId').value;
        const userPw = document.getElementById('password').value;
        const userName = document.getElementById('userName').value;
        const phone = document.getElementById('phoneNumber').value;
        const checkUserPw = document.getElementById('checkUserPassword').value;

const idRegex = /^[a-zA-Z0-9-_]{3,14}$/;
        if (userId.length == 0) {
            alert("아이디를 입력하세요.");
            return false;
        } else if(!idRegex.test(userId)){alert("아이디는 3~14자 영문, 숫자, 특수문자(-,_)를 포함할 수 있습니다.");
        return false;
        }


        if (userPw.length == 0 || userPw != checkUserPw) {
            alert("비밀번호가 비어있거나 일치하지 않습니다");
            return false;
        }


        const nameRegex = /^[가-힣]+$/;
            if (userName.length == 0) {
                alert("이름을 입력해주세요!");
                return false;
            }
            else if (!nameRegex.test(userName)) {
                alert("이름은 한글만 입력 가능합니다.");
                return false;
            }

        const phoneRegex = /^[0-9]{10,11}$/;
                if (!phone) {
                    alert ("핸드폰 번호를 입력해주세요.");
                    return false;
                  } else if (!phoneRegex.test(phone)) {
                    alert("휴대폰 번호는 숫자 10~11자리여야 합니다.");
                    return false;
                  }
        return true;
        }

